<?php
$conexao = new mysqli($servidor, $usuario, $senha) OR exit($conexao->error);