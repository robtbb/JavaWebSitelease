<?php

// Incluir os arquivos do PHPMailer
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';
require '../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pegar e sanitizar o nome do usuário
    $nomeUsuario = trim(htmlspecialchars($_POST['nome-do-usuario'], ENT_QUOTES, 'UTF-8'));

    // Validar o nome
    if (strlen($nomeUsuario) > 50 || !preg_match('/^[a-zA-Z\s]+$/', $nomeUsuario)) {
        die('Nome do usuário inválido.');
    }

    // Pegar e validar o e-mail
    $emailDestinatario = filter_var($_POST['email-do-usuario'], FILTER_SANITIZE_EMAIL);
    if (!filter_var($emailDestinatario, FILTER_VALIDATE_EMAIL)) {
        die('O endereço de e-mail fornecido não é válido.');
    }

    // Mensagem do e-mail
    $mensagem = 'Olá, ' . $nomeUsuario . ',<br><br>';
    $mensagem .= 'Obrigado por entrar em contato com a SiteLease. ';
    $mensagem .= 'Recebemos sua mensagem e nossa equipe está analisando o seu pedido. ';
    $mensagem .= 'Em breve, entraremos em contato para fornecer mais informações.<br><br>';
    $mensagem .= 'Atenciosamente,<br>Equipe SiteLease';

    // Criar instância do PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = getenv('SMTP_USERNAME'); // Use variáveis de ambiente
        $mail->Password = getenv('SMTP_PASSWORD');
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->CharSet = 'UTF-8';

        // Remetente e destinatário
        $mail->setFrom('contatositelease@gmail.com', 'Site Lease');
        $mail->addAddress($emailDestinatario, $nomeUsuario);

        // Conteúdo do e-mail
        $mail->isHTML(true);
        $mail->Subject = 'E-mail enviado via PHPMailer by Gabriel & Robert';
        $mail->Body    = $mensagem;
        $mail->AltBody = strip_tags($mensagem);

        // Enviar o e-mail
        $mail->send();
        echo 'Mensagem enviada com sucesso!';
    } catch (Exception $e) {
        // Registrar erro no log e exibir mensagem genérica
        error_log("Erro ao enviar e-mail: {$mail->ErrorInfo}");
        echo 'Ocorreu um problema ao enviar sua mensagem. Tente novamente mais tarde.';
    }
} else {
    echo 'Por favor, preencha o formulário corretamente.';
}


?>
