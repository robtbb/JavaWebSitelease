<?php
$servidor = "localhost";
$usuario  = "root";
$senha    = "2001";

$NomeDoBanco = "site_lease_chivunk";
$NomeDaTabela1 = "dados_cliente";